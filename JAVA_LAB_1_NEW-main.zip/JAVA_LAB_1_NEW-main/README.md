# JAVA_LAB_1_NEW 

Read Java_lab1.java before checking the other files
